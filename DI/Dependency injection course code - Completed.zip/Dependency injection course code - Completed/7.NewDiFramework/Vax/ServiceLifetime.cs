﻿namespace Vax;

public enum ServiceLifetime
{
    Transient,
    Singleton
}
