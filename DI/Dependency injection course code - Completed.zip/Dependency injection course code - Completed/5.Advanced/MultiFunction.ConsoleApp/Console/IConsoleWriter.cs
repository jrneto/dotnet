﻿namespace MultiFunction.ConsoleApp.Console;

public interface IConsoleWriter
{
    void WriteLine(string text);
}
