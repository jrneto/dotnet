﻿namespace ScrutorScanning.ConsoleApp.Services;

public interface IService
{
    
}