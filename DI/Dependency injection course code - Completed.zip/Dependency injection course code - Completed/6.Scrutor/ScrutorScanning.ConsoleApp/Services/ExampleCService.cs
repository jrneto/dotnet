﻿using ScrutorScanning.ConsoleApp.Attributes;
using ScrutorScanning.ConsoleApp.ServiceMarkers;

namespace ScrutorScanning.ConsoleApp.Services;

//[Scoped]
public class ExampleCService : IExampleCService
{

}

public interface IExampleCService
{

}
