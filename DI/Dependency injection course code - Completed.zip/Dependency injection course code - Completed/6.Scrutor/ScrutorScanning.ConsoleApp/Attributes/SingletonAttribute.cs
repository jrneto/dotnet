﻿namespace ScrutorScanning.ConsoleApp.Attributes;

[AttributeUsage(AttributeTargets.Class)]
public class SingletonAttribute : Attribute
{

}
