﻿namespace ScrutorScanning.ConsoleApp.ServiceMarkers;

public interface IScopedService
{

}
