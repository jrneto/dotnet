﻿namespace MultiFunction.ConsoleApp.Handlers;

public interface IHandler
{
    Task HandleAsync();
}
