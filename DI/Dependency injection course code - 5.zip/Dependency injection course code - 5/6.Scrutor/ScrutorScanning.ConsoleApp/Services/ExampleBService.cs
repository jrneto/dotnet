﻿namespace ScrutorScanning.ConsoleApp.Services;

public class ExampleBService : IExampleBService
{

}

public interface IExampleBService
{

}
