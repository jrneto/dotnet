﻿namespace ScrutorScanning.ConsoleApp.Services;

public class ExampleAService : IExampleAService
{

}

public interface IExampleAService
{

}
