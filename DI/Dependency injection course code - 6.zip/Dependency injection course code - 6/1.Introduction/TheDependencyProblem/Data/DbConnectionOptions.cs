namespace TheDependencyProblem.Data;

public class DbConnectionOptions
{
    public string ConnectionString { get; init; } = default!;
}
