﻿namespace ResolvingDeps.Mvc;

public class ServiceToInject
{
    public string Message => "I was injected!";
}
