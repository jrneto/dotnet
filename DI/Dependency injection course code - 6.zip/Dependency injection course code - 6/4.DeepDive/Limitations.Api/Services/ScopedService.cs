﻿namespace Limitations.Api.Services;

public class ScopedService
{
    public Guid Id { get; } = Guid.NewGuid();
}
