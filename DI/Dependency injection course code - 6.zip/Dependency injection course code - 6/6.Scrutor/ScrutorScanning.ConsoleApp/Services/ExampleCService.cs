﻿namespace ScrutorScanning.ConsoleApp.Services;

public class ExampleCService : IExampleCService
{

}

public interface IExampleCService
{

}
