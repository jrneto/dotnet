﻿namespace CustomScope.ConsoleApp;

public class ExampleService
{
    public Guid Id { get; } = Guid.NewGuid();
}
