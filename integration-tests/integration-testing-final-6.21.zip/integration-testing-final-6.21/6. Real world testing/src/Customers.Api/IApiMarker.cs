﻿namespace Customers.Api;

public interface IApiMarker
{
    
}