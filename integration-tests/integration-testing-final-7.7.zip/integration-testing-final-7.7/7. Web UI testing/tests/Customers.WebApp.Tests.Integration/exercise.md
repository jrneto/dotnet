# Write these test cases

## GetAll
- GetAll_ContainsCustomer_WhenCustomerExists

## Update
- Update_UpdateCustomer_WhenDataIsValid
- Update_ShowsError_WhenEmailIsInvalid

## Delete
- Delete_DeletesCustomer_WhenCustomerExists
