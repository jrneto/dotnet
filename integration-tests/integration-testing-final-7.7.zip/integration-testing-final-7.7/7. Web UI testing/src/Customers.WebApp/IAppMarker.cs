namespace Customers.WebApp;

public interface IAppMarker
{
    
}